/**
 * Copyright (c) 2008-2009 Glaxstar Ltd. All rights reserved.
 */

var EXPORTED_SYMBOLS = [];

const Cu = Components.utils;

Cu.import("resource://glaxdigg/gsCommon.js");

/**
 * GlaxDigg.CM namespace.
 */
if ("undefined" == typeof(GlaxDigg.CM)) {
  GlaxDigg.CM = {};
};
